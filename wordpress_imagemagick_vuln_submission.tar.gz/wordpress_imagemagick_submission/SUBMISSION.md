# WordPress ImageMagick Engine Buffer Overflow Vulnerability

## Summary
Buffer overflow in libwmf library affecting WordPress ImageMagick Engine plugin (30,000+ installations)

## Vulnerability Details
- **Component**: libwmf library (used by ImageMagick)
- **Function**: SetColor() at bmp.h:1303
- **Issue**: Missing bounds check on x/y coordinates
- **Impact**: Apache process crash (Segmentation fault), potential RCE

## Proof of Concept
1. Install WordPress + ImageMagick Engine plugin
2. Enable WMF file upload support
3. Upload malicious WMF file (evil_poly_extreme.wmf)
4. Apache processes crash with Segmentation fault (11)

## Evidence
- test_libwmf_setcolor.c - Standalone PoC with ASAN verification
- wordpress_crash_evidence.txt - Apache crash logs
- evil_poly_extreme.wmf - Malicious WMF file
- Video demonstration - [上传你的视频]

## Affected Versions
- libwmf: All versions 0.2.x
- ImageMagick: All versions using libwmf
- WordPress ImageMagick Engine: All versions

## CVSS Score
8.8 High (AV:N/AC:L/PR:L/UI:N/S:C/C:H/I:H/A:H)

## Timeline
- 2026-03-13: Vulnerability discovered
- 2026-03-13: PoC developed and verified
- 2026-03-13: WordPress crash confirmed
- 2026-03-13: Reported to Patchstack/Wordfence
